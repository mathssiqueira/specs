#!/bin/bash

sleep 15
echo "Executando UPDATES no banco..."
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.config SET default_lang = 'pt_BR';"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.usrgrp SET name = 'Specs administrators' WHERE usrgrpid = 7;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget_field SET value_str='Host' WHERE widget_fieldid=2;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget_field SET value_str='Nome' WHERE widget_fieldid=4;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget_field SET value_str='Uso' WHERE widget_fieldid=8;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget SET name='Top hosts por uso de CPU' WHERE widgetid=1;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget SET name='Performance' WHERE widgetid=2;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget SET name='Hora Local' WHERE widgetid=4;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget SET name='Problemas' WHERE widgetid=9;"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.hosts SET host='Specs Server' WHERE hostid=10084"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.hosts SET host='Linux by Specs agent' WHERE hostid=10001"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.hosts SET host='Specs server health' WHERE hostid=10047"
PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.events SET name = 'Linux: Specs agent is not available (for 3m)' WHERE name = 'Linux: Zabbix agent is not available (for 3m)';"


PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -t -A -c "SELECT hostid, host FROM public.hosts WHERE host LIKE '%Zabbix%' ORDER BY hostid ASC" | while IFS='|' read -r hostid host; do   
    new_host=$(echo "$host" | sed 's/Zabbix/Specs/g')
    PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.hosts SET host='$new_host' WHERE hostid=$hostid;"

done

PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -t -A -c "SELECT itemid, name_resolved FROM public.item_rtname WHERE name_resolved LIKE '%Zabbix%' ORDER BY itemid ASC" | while IFS='|' read -r itemid name_resolved; do   
    new_host=$(echo "$name_resolved" | sed 's/Zabbix/Specs/g')
    PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.item_rtname SET name_resolved='$new_host' WHERE itemid=$itemid;"

done

PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -t -A -c "SELECT itemid, name_resolved_upper FROM public.item_rtname WHERE name_resolved_upper LIKE '%ZABBIX%' ORDER BY itemid ASC" | while IFS='|' read -r itemid name_resolved_upper; do   
    new_host=$(echo "$name_resolved_upper" | sed 's/ZABBIX/SPECS/g')
    PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.item_rtname SET name_resolved_upper='$new_host' WHERE itemid=$itemid;"

done

PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -t -A -c "SELECT widgetid, name FROM public.widget WHERE name LIKE '%Zabbix%' ORDER BY widgetid ASC" | while IFS='|' read -r widgetid name; do   
    new_host=$(echo "$name" | sed 's/Zabbix/Specs/g')
    PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget SET name='$new_host' WHERE widgetid=$widgetid;"

done

PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -t -A -c "SELECT widget_fieldid, value_str FROM public.widget_field WHERE value_str LIKE '%Zabbix%' ORDER BY widget_fieldid ASC" | while IFS='|' read -r widget_fieldid value_str; do   
    new_host=$(echo "$name" | sed 's/Zabbix/Specs/g')
    PGPASSWORD="${DB_PASSWORD}" psql -h specs-db -U "${DB_USER}" -d "zabbix" -c "UPDATE public.widget_field SET value_str='$new_host' WHERE widget_fieldid=$widget_fieldid;"

done


echo "UPDATES finalizados"

#Customização logotipos, footer, 
echo "
<?php
return [
    'BRAND_LOGO' => './assets/img/main-logo.svg',
    'BRAND_LOGO_SIDEBAR' => './assets/img/main-sidebar.svg',
    'BRAND_LOGO_SIDEBAR_COMPACT' => './assets/img/main-sidebar.svg',
    'BRAND_FOOTER' => 'Specs.Digital - Av. Francisco Matarazzo, 404, Conj. 1004, cep 05001-000',
    'BRAND_HELP_URL' => 'https://specs.digital/'
];" > /usr/share/zabbix/local/conf/brand.conf.php

#Customizando nome Specs Digital abaixo do logo no meu lateral
echo "<?php
// Zabbix GUI configuration file.
global \$DB, \$HISTORY;

\$DB['TYPE']     = getenv('DB_SERVER_TYPE');
\$DB['SERVER']   = getenv('DB_SERVER_HOST');
\$DB['PORT']     = getenv('DB_SERVER_PORT');
\$DB['DATABASE'] = getenv('DB_SERVER_DBNAME');
\$DB['USER']     = (! getenv('VAULT_TOKEN') || ! getenv('ZBX_VAULTURL')) ? getenv('DB_SERVER_USER') : '';
\$DB['PASSWORD'] = (! getenv('VAULT_TOKEN') || ! getenv('ZBX_VAULTURL')) ? getenv('DB_SERVER_PASS') : '';

// Schema name. Used for PostgreSQL.
\$DB['SCHEMA'] = getenv('DB_SERVER_SCHEMA');

if (getenv('ZBX_SERVER_HOST')) {
    \$ZBX_SERVER      = getenv('ZBX_SERVER_HOST');
    \$ZBX_SERVER_PORT = getenv('ZBX_SERVER_PORT');
}
\$ZBX_SERVER_NAME = 'Specs.Digital';

// Used for TLS connection.
\$DB['ENCRYPTION']               = getenv('ZBX_DB_ENCRYPTION') == 'true' ? true: false;
\$DB['KEY_FILE']                 = getenv('ZBX_DB_KEY_FILE');
\$DB['CERT_FILE']                = getenv('ZBX_DB_CERT_FILE');
\$DB['CA_FILE']                  = getenv('ZBX_DB_CA_FILE');
\$DB['VERIFY_HOST']              = getenv('ZBX_DB_VERIFY_HOST') == 'true' ? true: false;
\$DB['CIPHER_LIST']              = getenv('ZBX_DB_CIPHER_LIST') ? getenv('ZBX_DB_CIPHER_LIST') : '';

// Vault configuration. Used if database credentials are stored in Vault secrets manager.
\$DB['VAULT']                    = getenv('ZBX_VAULT');
\$DB['VAULT_URL']                = getenv('ZBX_VAULTURL');
\$DB['VAULT_DB_PATH']            = getenv('ZBX_VAULTDBPATH');
\$DB['VAULT_TOKEN']              = getenv('VAULT_TOKEN');

if (file_exists('/etc/zabbix/web/certs/vault.crt')) {
   \$DB['VAULT_CERT_FILE'] = '/etc/zabbix/web/certs/vault.crt';
}
elseif (file_exists(getenv('ZBX_VAULTCERTFILE'))) {
   \$DB['VAULT_CERT_FILE'] = getenv('ZBX_VAULTCERTFILE');
}
else {
   \$DB['VAULT_CERT_FILE'] = '';
}

if (file_exists('/etc/zabbix/web/certs/vault.key')) {
   \$DB['VAULT_KEY_FILE'] = '/etc/zabbix/web/certs/vault.key';
}
elseif (file_exists(getenv('ZBX_VAULTKEYFILE'))) {
   \$DB['VAULT_KEY_FILE'] = getenv('ZBX_VAULTKEYFILE');
}
else {
   \$DB['VAULT_KEY_FILE'] = '';
}

\$DB['VAULT_CACHE']              = getenv('ZBX_VAULTCACHE') == 'true' ? true: false;
\$DB['DOUBLE_IEEE754']           = getenv('DB_DOUBLE_IEEE754') == 'true' ? true: false;

\$IMAGE_FORMAT_DEFAULT  = IMAGE_FORMAT_PNG;

// Elasticsearch url (can be string if same url is used for all types).
\$history_url = str_replace(\"'\",\"\\\"\",getenv('ZBX_HISTORYSTORAGEURL'));
\$HISTORY['url']   = (json_decode(\$history_url)) ? json_decode(\$history_url, true) : \$history_url;
// Value types stored in Elasticsearch.
\$storage_types = str_replace(\"'\",\"\\\"\",getenv('ZBX_HISTORYSTORAGETYPES'));

\$HISTORY['types'] = (json_decode(\$storage_types)) ? json_decode(\$storage_types, true) : array();

// Used for SAML authentication.
if (file_exists('/etc/zabbix/web/certs/sp.key')) {
   \$SSO['SP_KEY'] = '/etc/zabbix/web/certs/sp.key';
}
elseif (file_exists(getenv('ZBX_SSO_SP_KEY'))) {
   \$SSO['SP_KEY'] = getenv('ZBX_SSO_SP_KEY');
}
else {
   \$SSO['SP_KEY'] = '';
}

if (file_exists('/etc/zabbix/web/certs/sp.crt')) {
   \$SSO['SP_CERT'] = '/etc/zabbix/web/certs/sp.crt';
}
elseif (file_exists(getenv('ZBX_SSO_SP_CERT'))) {
   \$SSO['SP_CERT'] = getenv('ZBX_SSO_SP_CERT');
}
else {
   \$SSO['SP_CERT'] = '';
}

if (file_exists('/etc/zabbix/web/certs/idp.crt')) {
   \$SSO['IDP_CERT'] = '/etc/zabbix/web/certs/idp.crt';
}
elseif (file_exists(getenv('ZBX_SSO_IDP_CERT'))) {
   \$SSO['IDP_CERT'] = getenv('ZBX_SSO_IDP_CERT');
}
else {
   \$SSO['IDP_CERT'] = '';
}

\$sso_settings = str_replace(\"'\",\"\\\"\",getenv('ZBX_SSO_SETTINGS'));
\$SSO['SETTINGS'] = (json_decode(\$sso_settings)) ? json_decode(\$sso_settings, true) : array();

\$ALLOW_HTTP_AUTH = getenv('ZBX_ALLOW_HTTP_AUTH') == 'true' ? true: false;
" > /etc/zabbix/web/zabbix.conf.php

sed -i 's/<meta name="Author" content="Zabbix SIA" \/>/<meta name="Author" content="Specs.Digital" \/>/g' /usr/share/zabbix/include/classes/html/CHtmlPageHeader.php
sed -i 's|location = /favicon.ico {|location = /assets/img/favicon.ico {|g' /etc/zabbix/nginx.conf
sed -i 's|location = /favicon.ico {|location = /img/favicon.ico {|g' /etc/zabbix/nginx_ssl.conf
sed -i "s/_('Zabbix server is running')/_('Specs está rodando')/g" /usr/share/zabbix/app/partials/administration.system.info.php
sed -i "s/_('Zabbix server version')/_('Versão Specs server')/g" /usr/share/zabbix/app/partials/administration.system.info.php
sed -i "s/_('Zabbix frontend version')/_('Versão Specs frontend')/g" /usr/share/zabbix/app/partials/administration.system.info.php
sed -i "s/_('Global scripts on Zabbix server')/_('Global scripts on Specs server')/g" /usr/share/zabbix/app/partials/administration.system.info.php
sed -i "s/\$error = _s('Error! Unable to start Zabbix server.') . ' '/'\$error = _s('Error! Unable to start Specs server.') . ' '/g" /usr/share/zabbix/app/partials/administration.system.info.php
sed -i "s/_('Zabbix agent')/_('Specs agent')/g" /usr/share/zabbix/include/items.inc.php
sed -i "s/_('Zabbix agent (active)')/_('Specs agent (active)')/g" /usr/share/zabbix/include/items.inc.php
sed -i "s/_('Zabbix internal')/_('Specs internal')/g" /usr/share/zabbix/include/items.inc.php
sed -i "s/_('Zabbix trapper')/_('Specs trapper')/g" /usr/share/zabbix/include/items.inc.php
sed -i "s/_('Zabbix')/_('Specs')/g" /usr/share/zabbix/include/page_header.php



echo "Configuração concluída!"
exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf

