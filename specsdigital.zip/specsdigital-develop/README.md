# specsdigital
User: Admin 
Password: zabbix
