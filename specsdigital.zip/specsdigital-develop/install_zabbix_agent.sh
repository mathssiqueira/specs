#!/bin/bash

# Definir variáveis
SPECS_SERVER="localhost"  # Substitua pelo IP ou domínio do Zabbix Server
HOSTNAME=$(cat /etc/hostname)

echo "Update packages..."
sudo apt update -y

echo "Install Agent repository - 7.0 version"
wget https://repo.zabbix.com/zabbix/7.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_7.0-2+ubuntu24.04_all.deb
sudo dpkg -i zabbix-release_7.0-2+ubuntu24.04_all.deb

echo "Install Specs Agent"
sudo apt update
sudo apt install zabbix-agent -y

echo "Instalando o Zabbix Agent..."
sudo apt install -y zabbix-agent

echo "Configurando o Zabbix Agent com senha..."
echo "Configuring Agent"
echo "
PidFile=/run/zabbix/zabbix_agentd.pid
LogFile=/var/log/zabbix/zabbix_agentd.log
LogFileSize=0
DebugLevel=3
LogRemoteCommands=1
Server=${SPECS_SERVER}
ListenPort=10050
ListenIP=0.0.0.0
StartAgents=10
ServerActive=${SPECS_SERVER}
Hostname=${HOSTNAME}
HostnameItem=${HOSTNAME}
AllowKey=system.run[*]
HostMetadata=${1}
HostMetadataItem=${HOSTNAME}
Include=/etc/zabbix/zabbix_agentd.d/*.conf" > /etc/zabbix/zabbix_agentd.conf

echo "Open firewall Ports"
sudo ufw allow 10050/tcp
sudo ufw allow 10051/tcp

echo "Enable/Start Specs Agent..."
sudo systemctl enable zabbix-agent
sudo systemctl restart zabbix-agent

echo "Finished Install and Configuration Specs Agent!"
